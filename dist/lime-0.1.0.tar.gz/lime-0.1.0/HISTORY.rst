=======
History
=======

0.1.0 (2018-08-11)
------------------

* First release on PyPI.
