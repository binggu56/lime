========
scitools
========


.. image:: https://img.shields.io/pypi/v/scitools.svg
        :target: https://pypi.python.org/pypi/scitools

.. image:: https://img.shields.io/travis/audreyr/scitools.svg
        :target: https://travis-ci.org/audreyr/scitools

.. image:: https://readthedocs.org/projects/scitools/badge/?version=latest
        :target: https://scitools.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status




Python Boilerplate contains all the boilerplate you need to create a Python package.


* Free software: MIT license
* Documentation: https://scitools.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
